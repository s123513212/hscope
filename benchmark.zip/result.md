 √ = true positive, * = false positive, × = false negative.


| APP Type             | App Name              | Hscope Result | ArkAnalyzer Result | Ground Truth |
| -------------------- | --------------------- | :-----------: | :----------------: | :----------: |
| **aliasing (3)**     | Aliasing              |       √       |         √          |      1       |
|                      | Aliasing2             |       √       |         √          |      1       |
|                      | Aliasing3             |       √       |         √          |      1       |
| **import (3)**       | DynamicImport         |       ×       |         ×          |      1       |
|                      | Import1               |       √       |         √          |      1       |
|                      | Import2               |       √       |         ×          |      1       |
| **array (3)**        | ArrayCopy             |       √       |         ×          |      1       |
|                      | Array1                |       √       |         ×          |      1       |
|                      | ArrayAccess           |       √       |         ×          |      1       |
| **lifecycle (3)**    | AbilityLifeCycle1     |       √       |         ×          |      1       |
|                      | AbilityLifeCycle2     |       √       |         ×          |      1       |
|                      | AbilityLifeCycle3     |       √       |         √          |      1       |
| **OS (4)**           | LocalStorage          |       ×       |         ×          |      1       |
|                      | Internal              |       √       |         ×          |      1       |
|                      | LogNoLeak             |               |         *          |      0       |
|                      | Publicapi             |       √       |         ×          |      1       |
| **Language (11)**    | AcrossFuncInfunc      |       √       |         √          |      1       |
|                      | Reflect               |       ×       |         √          |      1       |
|                      | AcrossFunc            |       √       |         √          |      1       |
|                      | SourceCodeSpecific    |       √       |         ×          |      1       |
|                      | CallWithArgs          |       √       |         ×          |      1       |
|                      | VirtualDispatch       |       ×       |         ×          |      1       |
|                      | Loop1                 |       √       |         ×          |      1       |
|                      | Loop2                 |       √       |         ×          |      1       |
|                      | UnreachableCode       |               |                    |      0       |
|                      | Stringop              |       √       |         ×          |      1       |
|                      | Obfuscate             |       ×       |         ×          |      1       |
| **Background (3)**   | BackgroundTask1       |       √       |         ×          |      1       |
|                      | BackgroundTask2       |       √       |         ×          |      1       |
|                      | Thread                |       √       |         ×          |      1       |
| **Indirect (5)**     | HealthSequence        |       √       |         ×          |      1       |
|                      | Bluetooth             |       √       |         ×          |      1       |
|                      | Button1               |       √       |         ×          |      1       |
|                      | Button2               |       √       |         ×          |      1       |
|                      | Indirectcall          |       √       |         ×          |      1       |
| **@state (4)**       | PropState             |       √       |         ×          |      1       |
|                      | Linkstate             |       √       |         ×          |      1       |
|                      | State1                |       √       |         ×          |      1       |
|                      | State2                |       √       |         ×          |      1       |
| **ICC & Router (3)** | Icc1router            |       √       |         ×          |      1       |
|                      | Icc2ChildComponent    |       √       |         √          |      1       |
|                      | Icc3AppStorage        |       √       |         ×          |      1       |
| **NoLeak (8)**       | ImpossibleLifecycle   |               |                    |      0       |
|                      | ImpossibleControlFlow |       *       |                    |      0       |
|                      | NoLeakArray1          |       *       |         *          |      0       |
|                      | OverwriteValue        |               |                    |      0       |
|                      | ObjSensitive          |               |                    |      0       |
|                      | FieldSensitivity      |               |                    |      0       |
|                      | HashMapAccess         |       *       |                    |      0       |
|                      | Inheritance           |       *       |                    |      0       |
