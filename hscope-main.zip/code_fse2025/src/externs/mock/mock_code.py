def on(callback):
    callback()