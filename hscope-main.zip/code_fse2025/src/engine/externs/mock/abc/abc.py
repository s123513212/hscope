def then(callback):
    callback()
