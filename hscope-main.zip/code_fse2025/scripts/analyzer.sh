# #! /bin/sh

# clear

# if [ $# -eq 0 ]; then
#     echo "$0 <path>"
#     exit 1
# fi


# ROOT_DIR=$(realpath $0)
# ROOT_DIR=$(dirname $ROOT_DIR)
# ROOT_DIR=$(dirname $ROOT_DIR)

# # TARGET_PATH=$(realpath "$1")

# CMD="python $ROOT_DIR/src/analyze.py"
# OUTPUT_PATH="$ROOT_DIR/test/analyzer_workspace"
# OPTIONS="run  -f -d  -w $OUTPUT_PATH"
# echo $CMD $OPTIONS  $@ 
# # $CMD $OPTIONS $TARGET_PATH
# $CMD $OPTIONS $@

# # if [ $? -ne 0 ]; then
# #     exit 1
# # fi

# # echo "============="
# # $ROOT_DIR/taint/engine/scripts/dfview.py $OUTPUT_PATH


#! /bin/sh

clear

if [ $# -eq 0 ]; then
    echo "$0 <path>"
    exit 1
fi
# 
START_TIME=$(date +%s)
echo "start at: $(date)" >> "$LOG_FILE"
echo "start at: $(date)"

ROOT_DIR=$(realpath $0)
ROOT_DIR=$(dirname $ROOT_DIR)
ROOT_DIR=$(dirname $ROOT_DIR)

LOG_FILE="$ROOT_DIR/test/analyzer_workspace/analysis_log.txt"

CMD="python $ROOT_DIR/src/analyze.py"
OUTPUT_PATH="$ROOT_DIR/test/analyzer_workspace"
OPTIONS="run  -f -d  -w $OUTPUT_PATH"
echo $CMD $OPTIONS  $@ 


$CMD $OPTIONS $@ > "$LOG_FILE" 2>&1

# 
if [ $? -ne 0 ]; then
    echo "error check log: $LOG_FILE"
    exit 1
fi
END_TIME=$(date +%s)
ELAPSED_TIME=$((END_TIME - START_TIME))
echo "end: $(date)" >> "$LOG_FILE"
echo "total_time: $((ELAPSED_TIME/3600))hour$((ELAPSED_TIME%3600/60))min$((ELAPSED_TIME%60))sec" >> "$LOG_FILE"
echo "============="
$ROOT_DIR/taint/engine/scripts/dfview.py $OUTPUT_PATH >> "$LOG_FILE" 2>&1

echo "all complete: $LOG_FILE"
