#!/usr/bin/env python3

import os,sys
import inspect
import importlib
import dataclasses
import pprint
from engine.util import util
from taint import config1 as config
from taint.constants import (
    EventKind,
)
import taint.apps.event_return as er
from taint.apps.app_template import EventData
from taint.apps.app_registers import DefaultApp

class AppManager:
    def __init__(self, options):
        """
        the format of these hangles:
        {
            lang1: <hanglers>,
            lang2: <handlers>,
            ....
            "%"(ANY_LANG): <handlers>
        }
        """
        self.options = options
        self.optional_app_paths = options.apps
        self.prop_foreach_item_handlers = []
        self.submodule2_before_handlers = []
        self.sink_before_handlers = []
        self.prop_before_handlers = []
        self.call_before_handlers = []

        self.event_handlers = {
            EventKind.PROP_FOREACH_ITEM                   : self.prop_foreach_item_handlers,
            EventKind.TAINT_BEFORE                        : self.submodule2_before_handlers,
            EventKind.SINK_BEFORE                         : self.sink_before_handlers,
            EventKind.PROP_BEFORE                         : self.prop_before_handlers,
            EventKind.CALL_BEFORE                         : self.call_before_handlers,
            
        }

        self.register_default_apps()
        self.register_optional_apps()

        # if self.options.debug:
        #     self.list_installed_handlers()

    # 旧版 按照语言收集插件 执行插件顺序和注册顺序不同。新版按照注册顺序执行
    # def add_handler(self, handler_list, func, langs):
    #     # default_list = handler_list.get(config.ANY_LANG, [])
    #     handler_list.append()

    #     for each_lang in langs:
    #         if each_lang not in handler_list:
    #             # handler_list[each_lang] = default_list.copy()
    #             handler_list[each_lang] = []
    #         if each_lang == config.ANY_LANG:
    #             for key in handler_list:
    #                 handler_list[key].append(func)
    #         else:
    #             handler_list[each_lang].append(func)

    def add_handler(self, handler_list:list, func, langs):
        handler_list.append((langs, func))

    def notify(self, data:EventData):

        event_return = er.config_event_unprocessed()
        all_handlers = self.event_handlers.get(data.event, None)
        data.out_data = data.in_data

        if all_handlers is None:
            return event_return

        for langs, handler in all_handlers:
            if data.lang in langs or config.ANY_LANG in langs:
                if self.options.debug:
                    util.debug("Handling the event: ", EventKind[data.event], " with the handler: ", handler)
                current_return = handler(data)
                event_return = er.sync_event_return(current_return, event_return)
                if er.should_block_other_event_apps(event_return):
                    return event_return
                if er.is_event_successfully_processed(current_return):
                    data.in_data = data.out_data

        # if data.lang in all_handlers:
        #     for handler in all_handlers[data.lang]:
        #         if self.options.debug:
        #             util.debug("Handling the event: ", EventKind[data.event], " with the handler: ", handler)

        #         current_return = handler(data)
        #         event_return = er.sync_event_return(current_return, event_return)
        #         if er.should_block_other_event_apps(event_return):
        #             return event_return
        #         if er.is_event_successfully_processed(current_return):
        #             data.in_data = data.out_data

        # for handler in all_handlers.get(config.ANY_LANG, []):
        #     if self.options.debug:
        #         util.debug("Handling the event: ", EventKind[data.event], " with the handler: ", handler)

        #     current_return = handler(data)

        #     event_return = er.sync_event_return(current_return, event_return)
        #     if er.should_block_other_event_apps(event_return):
        #         return event_return
        #     if er.is_event_successfully_processed(current_return):
        #         data.in_data = data.out_data

        return event_return

    def register_default_apps(self):
        DefaultApp(self).enable()

    def register_extern_system(self, extern_system):
        if extern_system:
            self.register(
                event = EventKind.P2STATE_EXTERN_CALLEE,
                handler = extern_system.handle,
                langs = [config.ANY_LANG]
            )

    def register_optional_apps(self):
        def get_concrete_classes(module):
            classes = inspect.getmembers(module, inspect.isclass)

            for class_name, class_type in classes:
                if (not inspect.isabstract(class_type)
                    and len(class_type.__bases__) == 1
                    and class_type.__bases__[0] != object
                ):
                    # concrete_classes.append((class_name, class_type))
                    return class_type

            return None

        def create_instance_from_path(app_path):
            module_name = "tmp_module"
            spec = importlib.util.spec_from_file_location(module_name, app_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            concrete_class = get_concrete_classes(module)
            if concrete_class:
                concrete_class(self)

        for path in self.optional_app_paths:
            create_instance_from_path(path)

    def register(self, event, handler, langs = config.ANY_LANG):
        if event not in self.event_handlers:
            util.warn(f"Unknown event: {event}")
            return

        if isinstance(langs, str):
            langs = [langs]
        elif isinstance(langs, set):
            langs = list(langs)

        self.add_handler(self.event_handlers[event], handler, langs)

    def register_list(self, handler_list):
        for element in handler_list:
            self.register(element.event, element.handler, element.langs)

    def list_installed_handlers(self):
        for event in self.event_handlers:
            util.debug(f"Event: {EventKind[event]}, handlers: {str(self.event_handlers[event])}")
