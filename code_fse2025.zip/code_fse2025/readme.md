# Readme



Current environment need Linux +Python3.10



Install dependencies:

setuptools 

tree-sitter==0.24.0 

pandas 

pyarrow 

networkx 

numpy 

line_profiler 

matplotlib 

PyYAML



Usage:

./scripts/analyzer.sh  path/of/abc.txt

result is in the log file, if meets a sink, analyzer will out put "sink in"