import os



# from engine.util import util
ROOT_DIR    = os.path.realpath(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
print(ROOT_DIR)
LIAN_DIR    = os.path.join(os.path.dirname(ROOT_DIR), "engine/src")
TAINT_DIR   = os.path.join(os.path.dirname(ROOT_DIR), "taint/src")
print(TAINT_DIR)
#DEFAULT_WORKSPACE       = os.path.join(ROOT_DIR, "tests/submodule2_workspace")

MAX_METHOD_CALL_COUNT   = 30
TAINT_SOURCE            = os.path.join(ROOT_DIR, "src/taint/rules/hongmeng/src.yaml")
TAINT_SINK            = os.path.join(ROOT_DIR, "src/taint/rules/hongmeng/sink.yaml")
TAINT_PROPAGATION            = os.path.join(ROOT_DIR, "src/taint/rules/hongmeng/prop.yaml")


NO_TAINT                = 0
MAX_STMT_TAINT_ANALYSIS_COUNT = 3
ANY_LANG                                    = "%"

# RULE_KIND = util.SimpleEnum({
#     "SOURCE": 1,
#     "SINK": 2,
#     "propagation": 3,
# })